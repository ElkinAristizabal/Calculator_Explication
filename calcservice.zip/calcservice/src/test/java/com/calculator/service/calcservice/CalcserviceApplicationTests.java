package com.calculator.service.calcservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
